package Algorithm_I.week3;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {

    private ArrayList<LineSegment> jSegments = new ArrayList<>();

    public BruteCollinearPoints(Point[] points) {
        if (points == null || hasNull(points)) {
            throw new IllegalArgumentException();
        }
        Point[] pointsCoopy = points.clone();
        Arrays.sort(pointsCoopy);
        if (hasDuplicate(pointsCoopy)) {
            throw new IllegalArgumentException();
        }
        for (int first = 0; first < pointsCoopy.length - 3; first++) {
            for (int second = first + 1; second < pointsCoopy.length - 2; second++) {
                double slopeFS = pointsCoopy[first].slopeTo(pointsCoopy[second]);
                for (int third = second + 1; third < pointsCoopy.length - 1; third++) {
                    double slopeFT = pointsCoopy[first].slopeTo(pointsCoopy[third]);
                    if (slopeFS == slopeFT) {
                        for (int forth = third + 1; forth < pointsCoopy.length; forth++) {
                            double slopeFF = pointsCoopy[first].slopeTo(pointsCoopy[forth]);
                            if (slopeFS == slopeFF) {
                                jSegments.add(new LineSegment(pointsCoopy[first],
                                                              pointsCoopy[forth]));
                            }
                        }
                    }
                }
            }
        }
    }

    public int numberOfSegments() {
        return this.jSegments.size();

    }

    public LineSegment[] segments() {
        return this.jSegments.toArray(new LineSegment[jSegments.size()]);
    }

    private boolean hasDuplicate(Point[] points) {
        for (int i = 0; i < points.length - 1; i++) {
            if (points[i].compareTo(points[i + 1]) == 0) {
                return true;
            }
        }
        return false;
    }

    private boolean hasNull(Point[] points) {
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                return true;
            }
        }
        return false;
    }

    // public static void main(String[] args) {
    //
    //     week3.Point[] pointsCopy = { new week3.Point(3, 3), new week3.Point(2, 2), new week3.Point(1, 1), new week3.Point(0, 0) };
    //     week3.BruteCollinearPoints brute = new week3.BruteCollinearPoints(pointsCopy);
    //     StdOut.println("Number of Segments: " + brute.numberOfSegments());
    //     StdOut.println("Segments: " + Arrays.toString(brute.segments()));
    // }
}
