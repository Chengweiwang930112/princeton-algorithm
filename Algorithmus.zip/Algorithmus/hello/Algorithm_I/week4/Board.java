package Algorithm_I.week4;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Board {
    private final int[][] tiles;
    private int n;
    private int blankRow;
    private int blankCol;

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles) {
        if (tiles == null || tiles.length != tiles[0].length || tiles.length < 2) {
            throw new IllegalArgumentException();
        }
        this.tiles = copyOf(tiles);
        n = tiles.length;
        blankRow = -1;
        blankCol = -1;

        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if (tiles[row][col] == 0) {
                    blankRow = row;
                    blankCol = col;
                    return;
                }
            }
        }

    }

    // string representation of this board
    public String toString() {
        String s = "" + n + "\n";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                s += " " + tiles[i][j];
            }
            s += "\n";
        }
        return s;
    }

    // board dimension n
    public int dimension() {
        return n;
    }

    // number of tiles out of place
    public int hamming() {
        int hamming = n * n - 1;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == n - 1 && j == n - 1) {
                    continue;
                }
                if (tiles[i][j] == i * n + j + 1) {
                    hamming--;
                }
            }
        }
        return hamming;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
        int manhattan = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] != i * n + j + 1 && tiles[i][j] != 0) {
                    int j0 = tiles[i][j] % n - 1;
                    int i0 = tiles[i][j] / (n + 1);
                    manhattan += Math.abs(i - i0) + Math.abs(j - j0);
                }
            }
        }
        return manhattan;
    }

    // is this board the goal board?
    public boolean isGoal() {
        return hamming() == 0;
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == null) {
            return false;
        }
        else if (y.getClass() == this.getClass()) {
            Board by = (Board) y;
            return by.toString().equals(this.toString());
        }
        else {
            return false;
        }
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        List<Board> neighbors = new ArrayList<>();
        int i0 = -1, j0 = -1;
        out:
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] == 0) {
                    i0 = i;
                    j0 = j;
                    break out;
                }
            }
        }
        // check up
        if (i0 - 1 >= 0) {
            int[][] tilesCopy = new int[n][n];
            for (int i = 0; i < n; i++) {
                tilesCopy[i] = Arrays.copyOf(tiles[i], n);
            }
            // exchange
            int temp = tilesCopy[i0 - 1][j0];
            tilesCopy[i0 - 1][j0] = tilesCopy[i0][j0];
            tilesCopy[i0][j0] = temp;
            neighbors.add(new Board(tilesCopy));
        }
        // check down
        if (i0 + 1 < n) {
            int[][] tilesCopy = new int[n][n];
            for (int i = 0; i < n; i++) {
                tilesCopy[i] = Arrays.copyOf(tiles[i], n);
            }
            // exchange
            int temp = tilesCopy[i0 + 1][j0];
            tilesCopy[i0 + 1][j0] = tilesCopy[i0][j0];
            tilesCopy[i0][j0] = temp;
            neighbors.add(new Board(tilesCopy));
        }
        // check left
        if (j0 - 1 >= 0) {
            int[][] tilesCopy = new int[n][n];
            for (int i = 0; i < n; i++) {
                tilesCopy[i] = Arrays.copyOf(tiles[i], n);
            }
            // exchange
            int temp = tilesCopy[i0][j0 - 1];
            tilesCopy[i0][j0 - 1] = tilesCopy[i0][j0];
            tilesCopy[i0][j0] = temp;
            neighbors.add(new Board(tilesCopy));
        }
        // check right
        if (j0 + 1 < n) {
            int[][] tilesCopy = new int[n][n];
            for (int i = 0; i < n; i++) {
                tilesCopy[i] = Arrays.copyOf(tiles[i], n);
            }
            // exchange
            int temp = tilesCopy[i0][j0 + 1];
            tilesCopy[i0][j0 + 1] = tilesCopy[i0][j0];
            tilesCopy[i0][j0] = temp;
            neighbors.add(new Board(tilesCopy));
        }
        return neighbors;
    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        int[][] cloned = copyOf(tiles);
        if (blankRow != 0) {
            int swap = cloned[0][0];
            cloned[0][0] = cloned[0][1];
            cloned[0][1] = swap;
        }
        else {
            int swap = cloned[1][0];
            cloned[1][0] = cloned[1][1];
            cloned[1][1] = swap;
        }
        return new Board(cloned);
    }

    private int[][] copyOf(int[][] matrix) {
        int[][] clone = new int[matrix.length][];
        for (int row = 0; row < matrix.length; row++) {
            clone[row] = matrix[row].clone();
        }
        return clone;
    }

    // unit testing (not graded)
    public static void main(String[] args) {
        int[][] tiles1 = {
                {
                        1, 2, 3
                }, {
                        4, 0, 6
                }, {
                        7, 8, 5
                }
        };
        int[][] tiles2 = {
                {
                        1, 2, 3
                }, {
                        4, 0, 6
                }, {
                        7, 8, 5
                }
        };
        int[][] tiles3 = {
                {
                        1, 2, 3
                }, {
                        4, 7, 6
                }, {
                        0, 8, 5
                }
        };
        Board b1 = new Board(tiles1);
        Board b2 = new Board(tiles2);
        Board b1Twin = b1.twin();
        Board b3 = new Board(tiles3);
        StdOut.println("b1: \n" + b1.toString());
        StdOut.println("b1_twin: \n" + b1Twin.toString());
        StdOut.println("dimension: " + b1.dimension());
        StdOut.println("is goal? " + b1.isGoal());
        StdOut.println("hamming: " + b1.hamming());
        StdOut.println("manhattan: " + b1.manhattan());
        StdOut.println("b1 neighbors: ");
        b1.neighbors().forEach(StdOut::println);
        StdOut.println("b1: \n" + b1.toString());
        StdOut.println("b1 equals b2 ? " + b1.equals(b2));
        StdOut.println("b3: \n" + b3.toString());
        StdOut.println("b3 neighbors: ");
        b3.neighbors().forEach(StdOut::println);
    }
}
