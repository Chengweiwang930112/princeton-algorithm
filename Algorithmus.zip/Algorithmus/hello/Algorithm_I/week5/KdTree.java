package Algorithm_I.week5;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;

import java.util.LinkedList;
import java.util.List;

public class KdTree {

    private int size;
    private Node root;

    private static class Node {
        private final boolean isVertical;
        private final Point2D point;
        private Node leftOrUnder;
        private Node rightOrAbove;
        private RectHV rect;

        public Node(boolean isVertical, Point2D point, RectHV rect) {
            this.isVertical = isVertical;
            this.point = point;
            this.rect = rect;
        }

        public boolean isRightOrAbove(Point2D that) {
            return (!isVertical && point.y() >= that.y()) || (
                    isVertical && point.x() >= that.x());
        }

        public RectHV rectLU() {
            return isVertical
                   ? new RectHV(rect.xmin(), rect.ymin(), point.x(), rect.ymax())
                   : new RectHV(rect.xmin(), rect.ymin(), rect.xmax(), point.y());
        }

        public RectHV rectRA() {
            return isVertical
                   ? new RectHV(point.x(), rect.ymin(), rect.xmax(), rect.ymax())
                   : new RectHV(rect.xmin(), point.y(), rect.xmax(), rect.ymax());
        }
    }

    public KdTree() {
        size = 0;
        root = null;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void insert(Point2D p) {
        checkNull(p);
        if (root == null) {
            root = new Node(true, p, new RectHV(0, 0, 1, 1));
            size++;
        }
        else {
            Node prev = null;
            Node curr = root;
            while (curr != null) {
                if (curr.point.equals(p)) {
                    return;
                }
                prev = curr;
                curr = curr.isRightOrAbove(p) ? curr.leftOrUnder : curr.rightOrAbove;
            }
            if (prev.isRightOrAbove(p)) {
                prev.leftOrUnder = new Node(!prev.isVertical, p, prev.rectLU());
            }
            else {
                prev.rightOrAbove = new Node(!prev.isVertical, p, prev.rectRA());
            }
            size++;
        }
    }

    public boolean contains(Point2D p) {
        checkNull(p);
        Node node = root;
        while (node != null) {
            if (node.point.equals(p)) {
                return true;
            }
            node = node.isRightOrAbove(p) ? node.leftOrUnder : node.rightOrAbove;
        }
        return false;
    }

    public void draw() {
        checkNull(root);
        drawPoint(root);
    }

    private void drawPoint(Node node) {
        if (node == null) {
            return;
        }
        if (node.isVertical) {
            StdDraw.setPenRadius(0.002);
            StdDraw.setPenColor(StdDraw.RED);
            StdDraw.line(node.point.x(), node.rect.ymin(), node.point.x(), node.rect.ymax());
        }
        else {
            StdDraw.setPenRadius(0.002);
            StdDraw.setPenColor(StdDraw.BLUE);
            StdDraw.line(node.rect.xmin(), node.point.y(), node.rect.xmax(), node.point.y());
        }
        StdDraw.setPenRadius(0.01);
        StdDraw.setPenColor(StdDraw.BLACK);
        node.point.draw();
        drawPoint(node.leftOrUnder);
        drawPoint(node.rightOrAbove);
    }

    public Iterable<Point2D> range(RectHV rect) {
        checkNull(rect);
        List<Point2D> pointsInside = new LinkedList<>();
        traverseAndAdd(root, rect, pointsInside);
        return pointsInside;
    }

    private void traverseAndAdd(Node node, RectHV rect, List<Point2D> pointsInside) {
        if (node == null) {
            return;
        }
        if (rect.contains(node.point)) {
            pointsInside.add(node.point);
        }
        traverseAndAdd(node.leftOrUnder, rect, pointsInside);
        traverseAndAdd(node.rightOrAbove, rect, pointsInside);
    }

    public Point2D nearest(Point2D p) {
        checkNull(p);
        double min = Double.POSITIVE_INFINITY;
        return isEmpty() ? null : findNearest(p, root.point, root);
    }

    private Point2D findNearest(Point2D target, Point2D closest, Node node) {
        if (node == null) {
            return closest;
        }
        double closestDist = closest.distanceTo(target);
        if (node.rect.distanceTo(target) < closestDist) {
            double nodeDist = node.point.distanceTo(target);
            if (nodeDist < closestDist) {
                closest = node.point;
            }
            if (node.isRightOrAbove(target)) {
                closest = findNearest(target, closest, node.leftOrUnder);
                closest = findNearest(target, closest, node.rightOrAbove);
            }
            else {
                closest = findNearest(target, closest, node.rightOrAbove);
                closest = findNearest(target, closest, node.leftOrUnder);
            }
        }
        return closest;
    }

    private void checkNull(Object object) {
        if (object == null) {
            throw new IllegalArgumentException();
        }
    }
}
