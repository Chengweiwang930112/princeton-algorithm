package Algorithm_I.week5;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

public class PointSET {
    private TreeSet<Point2D> points;

    public PointSET() {
        points = new TreeSet<>();
    }

    public boolean isEmpty() {
        return points.isEmpty();
    }

    public int size() {
        return points.size();
    }

    public void insert(Point2D p) {
        checkNull(p);
        points.add(p);
    }

    public boolean contains(Point2D p) {
        checkNull(p);
        return points.contains(p);
    }

    public void draw() {
        checkNull(points);
        // Point2D p0 = new Point2D(0, 0);
        for (Point2D p : points) {
            p.draw();
        }
    } // draw all points to standard draw

    public Iterable<Point2D> range(RectHV rect) {
        checkNull(rect);
        Point2D minP = new Point2D(rect.xmin(), rect.ymin());
        Point2D maxP = new Point2D(rect.xmax(), rect.ymax());
        List<Point2D> pointsInside = new LinkedList<>();
        for (Point2D p : points.subSet(minP, true, maxP, true)) {
            if (p.x() >= rect.xmin() && p.x() <= rect.xmax()) {
                pointsInside.add(p);
            }
        }
        return pointsInside;
    }

    public Point2D nearest(Point2D p) {
        checkNull(p);
        double minDistance = Double.POSITIVE_INFINITY;
        Point2D nearestP = null;
        for (Point2D point : points) {
            if (p.distanceTo(point) < minDistance) {
                minDistance = p.distanceTo(point);
                nearestP = point;
            }
        }
        return nearestP;
    }

    private void checkNull(Object object) {
        if (object == null) {
            throw new IllegalArgumentException();
        }
    }

    public static void main(String[] args) {
        StdDraw.setPenRadius(0.01);
        StdDraw.setPenColor(StdDraw.BLACK);

        PointSET points = new PointSET();
        points.insert(new Point2D(0, 0));
        points.insert(new Point2D(0.1, 0.6));
        points.insert(new Point2D(0.3, 0.1));
        points.insert(new Point2D(0.9, 0.1));
        points.insert(new Point2D(0.9, 0.9));
        points.insert(new Point2D(0.9, 0.2));
        points.insert(new Point2D(0.2, 0.7));
        points.insert(new Point2D(0.3, 0.5));

        RectHV rect = new RectHV(0.05, 0.05, 0.6, 0.6);

        StdOut.println("nearst point to (0.2,0.3): " + points.nearest(new Point2D(0.2, 0.3)));
        StdOut.println("points in rectangle: ");
        for (Point2D p : points.range(rect)) {
            StdOut.println(p);
            p.draw();
        }
    }
}
