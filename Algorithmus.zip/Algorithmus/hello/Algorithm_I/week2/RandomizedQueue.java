package Algorithm_I.week2;
/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private int size = 0;
    private Item[] items;

    // construct an empty randomized queue
    public RandomizedQueue() {
        items = (Item[]) new Object[1];
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return size() == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return size;
    }

    // add the item
    public void enqueue(Item item) {
        if (size >= items.length) {
            Item[] newarr = (Item[]) new Object[items.length * 2];
            System.arraycopy(items, 0, newarr, 0, items.length);
            items = newarr;
        }
        items[size++] = item;
    }

    // remove and return a random item
    public Item dequeue() {
        int inew = 0;
        int indexToBeMoved = StdRandom.uniform(size);
        Item dequeued = items[indexToBeMoved];
        Item[] newitems = (Item[]) new Object[size];
        for (int iitems = 0; iitems < size; iitems++) {
            if (iitems != indexToBeMoved) {
                newitems[inew++] = items[iitems];
            }
        }
        items = newitems;
        size--;
        return dequeued;
    }

    // return a random item (but do not remove it)
    public Item sample() {
        return items[StdRandom.uniform(size)];
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new MyItr();
    }

    private class MyItr implements Iterator<Item> {
        int iterindex = 0;

        MyItr() {
            StdRandom.shuffle(items, 0, size);
        }

        public boolean hasNext() {
            return iterindex < size;
        }

        public Item next() {
            if (hasNext()) {
                return items[iterindex++];
            }
            else {
                throw new NoSuchElementException();
            }
        }
    }

    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<String> randomQ = new RandomizedQueue<>();
        StdOut.println(randomQ.isEmpty());
        StdOut.println("enqueuing ...");
        randomQ.enqueue("0");
        randomQ.enqueue("1");
        randomQ.enqueue("2");
        randomQ.enqueue("3");
        randomQ.enqueue("4");
        randomQ.enqueue("5");
        randomQ.enqueue("6");
        randomQ.enqueue("7");
        randomQ.enqueue("8");
        randomQ.enqueue("9");
        StdOut.println("There are " + randomQ.size() + " elements in week2.RandomizedQueue");

        Iterator<String> iter1 = randomQ.iterator();
        Iterator<String> iter2 = randomQ.iterator();
        Iterator<String> iter3 = randomQ.iterator();

        while (iter1.hasNext()) {
            StdOut.print(iter1.next() + " ");
        }
        StdOut.print("|| " + randomQ.sample());
        StdOut.println();
        while (iter2.hasNext()) {
            StdOut.print(iter2.next() + " ");
        }
        StdOut.print("|| " + randomQ.sample());
        StdOut.println();
        while (iter3.hasNext()) {
            StdOut.print(iter3.next() + " ");
        }
        StdOut.print("|| " + randomQ.sample());
    }
}
