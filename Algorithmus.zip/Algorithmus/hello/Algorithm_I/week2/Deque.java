package Algorithm_I.week2;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private Node first;
    private Node last;
    private int size;

    private class Node {
        public Item item = null;
        public Node next = null;
        public Node previous = null;
    }

    // construct an empty deque
    public Deque() {
        first = null;
        last = null;
        size = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the deque
    public int size() {
        return size;
    }

    // add the item to the front
    public void addFirst(Item item) {
        if (first == null) {
            first = new Node();
            first.item = item;
            last = first;
        }
        else {
            Node oldfirst = first;
            first = new Node();
            first.item = item;
            first.next = oldfirst;
            first.previous = null;
        }
        size++;
    }

    // add the item to the back
    public void addLast(Item item) {
        if (last == null) {
            last = new Node();
            last.item = item;
            first = last;
        }
        else {
            Node oldlast = last;
            last = new Node();
            last.item = item;
            oldlast.next = last;
            last.previous = oldlast;
        }
        size++;
    }

    // remove and return the item from the front
    public Item removeFirst() {
        Node removedfirst = first;
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        else if (size == 1) {
            first = null;
            last = null;
        }
        else {
            first = first.next;
            first.previous = null;
        }
        size--;
        return removedfirst.item;
    }

    // remove and return the item from the back
    public Item removeLast() {
        Node removedlast = last;
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        else if (size == 1) {
            first = null;
            last = null;
        }
        else {
            last = last.previous;
            last.next = null;
        }
        size--;
        return removedlast.item;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        return new Iterator<Item>() {
            private Node current = first;

            public boolean hasNext() {
                return current != null;
            }

            public Item next() {
                if (hasNext()) {
                    Item item = current.item;
                    current = current.next;
                    return item;
                }
                else {
                    throw new NoSuchElementException();
                }

            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    // unit testing (required)
    public static void main(String[] args) {
        Deque<String> dequeString = new Deque<>();
        dequeString.addFirst("2");
        dequeString.addFirst("1");
        dequeString.addLast("3");
        dequeString.addLast("4");

        StdOut.println("There are totally " + dequeString.size() + " items in week2.Deque");
        for (String s : dequeString) {
            StdOut.println(s);
        }

        dequeString.removeFirst();
        dequeString.removeLast();

        StdOut.println(
                "After removing there are totally " + dequeString.size() + " items in week2.Deque");
        for (String s : dequeString) {
            StdOut.println(s);
        }
    }
}
