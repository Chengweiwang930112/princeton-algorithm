package Algorithm_I.week2;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public static void main(String[] args) {
        RandomizedQueue<String> randomQ = new RandomizedQueue<>();
        if (args.length > 0 && Integer.parseInt(args[0]) >= 0) {
            int k = Integer.parseInt(args[0]);
            while (!StdIn.isEmpty()) {
                randomQ.enqueue(StdIn.readString());
            }
            int i = 0;
            for (String s : randomQ) {
                if (i == k) {
                    break;
                }
                else {
                    StdOut.println(s);
                    i++;
                }
            }
        }
    }
}
