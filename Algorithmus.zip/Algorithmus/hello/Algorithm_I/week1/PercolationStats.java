package Algorithm_I.week1;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private static final double CONFIDENCE_95 = 1.96;

    private int nn;

    private double[] threshold;


    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException();
        }
        else {
            nn = n;
            Percolation per = new Percolation(n);
            threshold = new double[trials];
            for (int i = 0; i < trials; i++) {
                threshold[i] = conductSim(per, n);
            }
        }
    }

    private double conductSim(Percolation percolation, int n) {
        while (!percolation.percolates()) {
            percolation.open(StdRandom.uniform(1, n + 1), StdRandom.uniform(1, n + 1));
        }
        return (1.0 * percolation.numberOfOpenSites()) / (n * n);
    }

    // sample mean of percolation threshold
    public double mean() {
        return StdStats.mean(threshold);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return StdStats.stddev(threshold);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - ((CONFIDENCE_95 * stddev()) / Math.sqrt(nn));
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean() + ((CONFIDENCE_95 * stddev()) / Math.sqrt(nn));
    }

    // test client (see below)
    public static void main(String[] args) {
        if (args.length >= 2) {
            int n = Integer.parseInt(args[0]);
            int trials = Integer.parseInt(args[1]);
            PercolationStats perStats = new PercolationStats(n, trials);
            StdOut.println("mean                    = " + perStats.mean());
            StdOut.println("stddev                  = " + perStats.stddev());
            StdOut.println("95% confidence interval = [" + perStats.confidenceLo() + ", " + perStats
                    .confidenceHi() + "]");
        }
    }
}
