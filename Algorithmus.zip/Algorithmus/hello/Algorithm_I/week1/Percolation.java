package Algorithm_I.week1;/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private int nn;

    private boolean[][] grid;

    private int openCount = 0;

    private WeightedQuickUnionUF wuf;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n > 0) {
            nn = n;
            wuf = new WeightedQuickUnionUF(n * n + 2);
            grid = new boolean[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    grid[i][j] = false;
                }
            }
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row < 1 || row > nn || col < 1 || col > nn) {
            throw new IllegalArgumentException();
        }
        else if (!grid[row - 1][col - 1]) {
            grid[row - 1][col - 1] = true;
            openCount++;
            applyUnions(row - 1, col - 1);
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row < 1 || row > nn || col < 1 || col > nn) {
            throw new IllegalArgumentException();
        }
        else {
            return grid[row - 1][col - 1];
        }
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row < 1 || row > nn || col < 1 || col > nn) {
            throw new IllegalArgumentException();
        }
        else {
            return grid[row - 1][col - 1] && (wuf.find(nn * (row - 1) + col) == wuf.find(0));
        }
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openCount;
    }

    // does the system percolate?
    public boolean percolates() {
        return wuf.find(0) == wuf.find(nn * nn + 1);
    }

    private void applyUnions(int i, int j) {
        applyUnionUp(i, j);
        applyUnionDown(i, j);
        applyUnionLeft(i, j);
        applyUnionURight(i, j);
    }

    private void applyUnionURight(int i, int j) {
        if (j + 1 < nn) {
            if (grid[i][j + 1]) {
                wuf.union(nn * i + j + 1, nn * i + j + 2);
            }
        }
    }

    private void applyUnionLeft(int i, int j) {
        if (j > 0) {
            if (grid[i][j - 1]) {
                wuf.union(nn * i + j + 1, nn * i + j);
            }
        }
    }

    private void applyUnionDown(int i, int j) {
        if (i + 1 < nn) {
            if (grid[i + 1][j]) {
                wuf.union(nn * i + j + 1, nn * (i + 1) + j + 1);
            }
        }
        else {
            // the node in the last row should be connected to bottom virtual node
            wuf.union(nn * (nn - 1) + j + 1, nn * nn + 1);
        }
    }

    private void applyUnionUp(int i, int j) {
        if (i > 0) {
            if (grid[i - 1][j]) {
                wuf.union(nn * i + j + 1, nn * (i - 1) + j + 1);
            }
        }
        else {
            // the node in the first row should be connected to top virtual node
            wuf.union(j + 1, 0);
        }
    }
}
