/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.DirectedCycle;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class WordNet {
    private int numV;
    private final Map<String, ArrayList<Integer>> noun2Id;
    private final Map<Integer, String> id2Noun;
    private SAP sap;


    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) {
            throw new IllegalArgumentException("");
        }
        numV = 0;
        noun2Id = new HashMap<>();
        id2Noun = new HashMap<>();
        readSynsets(synsets);
        readHypernyms(hypernyms);
    }

    private void readSynsets(String synsets) {
        In in = new In(synsets);
        String line;
        while ((line = in.readLine()) != null) {
            String[] strs = line.split(",");
            if (strs.length < 2) {
                continue;
            }
            numV++;
            int id = Integer.parseInt(strs[0]);
            id2Noun.put(id, strs[1]);
            String[] nouns = strs[1].split(" ");
            for (String noun : nouns) {
                ArrayList<Integer> nounIds = noun2Id.get(noun);
                if (nounIds != null) {
                    nounIds.add(id);
                }
                else {
                    ArrayList<Integer> nids = new ArrayList<>();
                    nids.add(id);
                    noun2Id.put(noun, nids);
                }
            }
        }
    }

    private void readHypernyms(String hypernyms) {
        In in = new In(hypernyms);
        Digraph digraph = new Digraph(numV);
        String line;
        while ((line = in.readLine()) != null) {
            String[] strs = line.split(",");
            if (strs.length < 2) {
                continue;
            }
            int start = Integer.parseInt(strs[0]);
            for (int i = 1; i < strs.length; ++i) {
                digraph.addEdge(start, Integer.parseInt(strs[i]));
            }
        }

        DirectedCycle dc = new DirectedCycle(digraph);
        if (dc.hasCycle()) {
            throw new IllegalArgumentException("");
        }
        int numRoot = 0;
        for (int i = 0; i < digraph.V(); i++) {
            if (digraph.outdegree(i) == 0) {
                ++numRoot;
                if (numRoot > 1) {
                    throw new IllegalArgumentException("");
                }
            }
        }
        sap = new SAP(digraph);
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return id2Noun.values();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) {
            throw new IllegalArgumentException("");
        }
        return noun2Id.containsKey(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        if (isNotNoun(nounA) || isNotNoun(nounB)) {
            throw new IllegalArgumentException("");
        }
        return sap.length(noun2Id.get(nounA), noun2Id.get(nounB));
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        if (isNotNoun(nounA) || isNotNoun(nounB)) {
            throw new IllegalArgumentException("");
        }
        return id2Noun.get(sap.ancestor(noun2Id.get(nounA), noun2Id.get(nounB)));
    }

    private boolean isNotNoun(String word) {
        return word == null || noun2Id.get(word) == null;
    }

    // do unit testing of this class
    public static void main(String[] args) {
        WordNet wn = new WordNet("Synsets.txt", "Hypernyms.txt");
        StdOut.println(
                "orange_juice and apple_juice: " + wn.distance("orange_juice", "apple_juice"));
    }
}
